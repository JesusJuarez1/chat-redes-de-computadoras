package chat;


public class Main {

    public static void main(String[] args) {
        Chat chat = new Chat();
    }
}